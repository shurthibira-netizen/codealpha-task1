# Credit Scoring Model

This project predicts loan approval using machine learning.

Algorithm used: Logistic Regression

Steps:

1. Load dataset
2. Preprocess data
3. Train model
4. Predict result

Output:
Model gives accuracy score.
